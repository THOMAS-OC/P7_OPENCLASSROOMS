<template>
  <div class="home">


    <div v-on:click="viewForm" class="btnCreatePost">
      <div></div>
      <div></div>
    </div>

    <form v-on:submit.prevent="createPost" class="createPost formInvisible">
      <input required v-model="title" placeholder="Titre" type="text">
      <textarea required v-model="content" placeholder="Contenu de votre post" name="" id="" cols="30" rows="10"></textarea>
      <input type="file" name="" id="" @change="onChange">
      <input type="submit" value="Poster">
      <!-- Bouton d'affichage -->
      <button v-on:click.prevent="hideForm">X</button>
    </form>

    <section>

      <article class="post" v-for="post in posts" :key="post">

        <the-post :class='post' :postId="post"></the-post>

      </article>

    </section>

  </div>
</template>

<script>
import ThePost from '@/components/ThePost.vue'

export default {
  name: 'HomeView',

  data(){
    return {
      posts : [],
      title : "",
      content : "",
      picturePost : null
    }
  },

  components: {
    ThePost
  },

  mounted(){
    this.$http.get("https://localhost:3001/api/auth/checkconnect")
    .then(()=>this.refreshPosts())
    .catch(err => {
        console.log(err);
        alert('Veuillez vous connecter svp.')
        this.$router.push('connect')
    })
    
  },

  created: function () {
    document.title = "Forum / GROUPOMANIA"
  },

  methods:{

    onChange(event) {
        this.picturePost = event.target.files[0]
    },

    refreshPosts(){
      // this.posts = []
      this.$http.get("https://localhost:3001/api/post")
      .then(response => {
          this.posts = response.data
      })
      .catch(error => {
        // User not connected
        if (error.response.data.userConnected == 'false') {
            alert("Veuillez vous connecter svp")
            this.$router.push("connect")
        }
        // ! User not connected
      })
    },

    returnUserId(){
      return window.localStorage.getItem("id")
    },

    createPost(){

      if (this.picturePost){
          const formData = new FormData()
          formData.append('picturePost', this.picturePost)
          formData.append('title', `${this.title}`)
          formData.append('content', `${this.content}`)
          this.$http.post(`https://localhost:3001/api/post/`, formData, {})
          .then(() => {
            this.refreshPosts()
          })
          .catch(err => console.log(err))
      }

      // REQUETE POST WITHOUT PICTURE
      else {
        this.$http.post("https://localhost:3001/api/post/", {
          title : this.title,
          content : this.content,
        })
        .then(() => this.refreshPosts())
        .catch(error => {
          // User not connected
          if (error.response.data.userConnected == 'false') {
              alert("Veuillez vous connecter svp")
              this.$router.push("connect")
          }
          // ! User not connected
        })
      }

      // RESET FORM
      this.picturePost = null
      this.title = ""
      this.content = ""
      window.setTimeout(this.hideForm, 500)
    },


    viewForm(){
      if (document.querySelector("form").className == "createPost formVisible"){
        this.hideForm()
      }
      else {
        document.querySelector("form").className = "createPost formVisible"
        document.querySelector("section").className = "section-replace"
      }
    },

    hideForm(){
      document.querySelector("form").className = "createPost formInvisible"
      document.querySelector("section").className = ""
    }

  }

}
</script>

<style scoped>

  h2{
    color: red;
  }

  section {
    height: auto;
    transition-duration: 1s;
    transform: translateY(-500px);
  }
  /* classe pour déplacer section vers le bas */

  .section-replace {
    transform: translateY(0px);
  }


  /* BOUTTON CREATION DE POSTE */

  .btnCreatePost{
    cursor: pointer;
    margin: 50px auto;
    width: 250px;
    height: 250px;
    border-radius: 50%;
    border: 3px solid #FD2D01;
    background-color: rgba(255, 255, 255, 0.601);
    position: relative;
    transition-duration: 0.5s;
  }

  .btnCreatePost:hover{
    transform: scale(1.1);
    box-shadow: 0px 0px 30px #FD2D01;
  }

  .btnCreatePost div{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, 50%) scale(0.8);
    width: 200px;
    height: 12px;
    background-color:#ffffff;
    transition-duration: 1s;
    border-radius: 15px;
    box-shadow: 0px 0px 30px #494949;
  }

  .btnCreatePost div:nth-child(2){
    transform: translate(-50%, 50%) rotate(90deg) scale(0.8);
  }

  /* FIN BOUTTON CREATION DE POSTE */

  /* FORMULAIRE CREATION DE POSTE */

  .createPost{
    width: 500px;
    height: 500px;
    background-color: #fff;
    margin: 50px auto;
    border-radius: 15px;
    border: 2px solid#FD2D01;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    padding: 10px 20px;
    position: relative;
    transition-duration: 1s;
    opacity: 0;
    transform: scale(0.2);
  }

  .createPost button{
    position: absolute;
    right: -10px;
    top: -10px;
    height: 50px;
    width: 50px;
    border-radius: 50%;
    background-color: #FD2D01;
    color: white;
    font-weight: bold;
    cursor: pointer;
    font-size: 20px;
  }

  textarea{
    height: 80%;
    width: 100%;
  }

  .formVisible{
    opacity: 1;
    transform: scaleY(1);
    transition-duration: 1s;
  }

  .formInvisible{
    opacity: 0;
    transform: scaleY(0);
    transition-duration: 1s;
  }

  /* FIN FORMULAIRE CREATION DE POSTE */

</style>